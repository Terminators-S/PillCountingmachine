import { ReactNode } from 'react';
import { Card, CardContent } from './ui/card';

export function StatCard({ label, value, hint, icon }: { label: string; value: string | number; hint?: string; icon?: ReactNode }) {
  return (
    <Card className='border border-border/90 shadow-sm'>
      <CardContent className='p-4'>
        <div className='flex items-center justify-between'>
          <p className='text-xs uppercase tracking-wide text-muted-foreground'>{label}</p>
          {icon}
        </div>
        <p className='mt-2 text-2xl font-semibold'>{value}</p>
        {hint ? <p className='mt-1 text-xs text-muted-foreground'>{hint}</p> : null}
      </CardContent>
    </Card>
  );
}
