'use client';

import { Badge } from './ui/badge';

interface LiveConnectionBadgeProps {
  state: 'connecting' | 'open' | 'closed' | 'error';
  lastSyncAt?: string;
}

const labelMap: Record<LiveConnectionBadgeProps['state'], string> = {
  connecting: 'Connecting',
  open: 'Live',
  closed: 'Disconnected',
  error: 'Error'
};

const variantMap: Record<LiveConnectionBadgeProps['state'], 'default' | 'success' | 'warning' | 'danger'> = {
  connecting: 'warning',
  open: 'success',
  closed: 'default',
  error: 'danger'
};

export function LiveConnectionBadge({ state, lastSyncAt }: LiveConnectionBadgeProps) {
  return (
    <div className='flex items-center gap-2 text-xs text-muted-foreground'>
      <Badge variant={variantMap[state]}>{labelMap[state]}</Badge>
      <span>{lastSyncAt ? `Last sync ${new Date(lastSyncAt).toLocaleTimeString()}` : 'No sync yet'}</span>
    </div>
  );
}
