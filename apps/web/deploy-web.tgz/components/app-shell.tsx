'use client';

import {
  Bell,
  ClipboardList,
  Cog,
  FileBarChart2,
  FileSearch,
  Home,
  LogOut,
  Package,
  Search,
  Shield,
  Truck,
  UserCog,
  Users,
  Wrench,
  LucideIcon
} from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';
import { ReactNode, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { clearTokens } from '../lib/auth';
import { apiRequest } from '../lib/api';
import { cn } from '../lib/utils';
import { AppBreadcrumbs } from './app-breadcrumbs';
import { LiveConnectionBadge } from './live-connection-badge';
import { ThemeToggle } from './theme-toggle';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { MeProfile } from '../types/api';

type NavItem = {
  href: string;
  label: string;
  icon: LucideIcon;
  disabled?: boolean;
};

const navItems: NavItem[] = [
  { href: '/overview', label: 'Overview', icon: Home },
  { href: '/jobs', label: 'Jobs / Sessions', icon: ClipboardList },
  { href: '/inventory', label: 'Inventory', icon: Package },
  { href: '/lots-expiry', label: 'Lots & Expiry', icon: FileSearch },
  { href: '/machines', label: 'Machines Fleet', icon: Truck },
  { href: '/maintenance', label: 'Maintenance', icon: Wrench, disabled: true },
  { href: '/reports', label: 'Reports', icon: FileBarChart2 },
  { href: '/users-roles', label: 'Users & Roles', icon: Users },
  { href: '/settings', label: 'Settings', icon: Cog },
  { href: '/audit-log', label: 'Audit Log', icon: Shield },
  { href: '/notifications', label: 'Notifications', icon: Bell, disabled: true }
] as const;

export function AppShell({
  children,
  connectionState,
  lastSyncAt
}: {
  children: ReactNode;
  connectionState: 'connecting' | 'open' | 'closed' | 'error';
  lastSyncAt?: string;
}) {
  const pathname = usePathname();
  const router = useRouter();

  const storeName = process.env.NEXT_PUBLIC_STORE_NAME || 'Pharmacy Operations';
  const storeLogo = process.env.NEXT_PUBLIC_STORE_LOGO_URL || '';

  const { data: me } = useQuery({
    queryKey: ['me'],
    queryFn: () => apiRequest<MeProfile>('/auth/me')
  });

  const sectionLabel = useMemo(() => {
    const matching = navItems.find((item) => pathname.startsWith(item.href));
    return matching?.label || 'Dashboard';
  }, [pathname]);

  return (
    <div className='min-h-screen bg-[radial-gradient(circle_at_20%_20%,rgba(34,211,238,0.08),transparent_42%),radial-gradient(circle_at_80%_0%,rgba(37,99,235,0.08),transparent_36%)]'>
      <div className='mx-auto flex w-full max-w-[1680px] gap-4 px-4 py-4 lg:px-6'>
        <aside className='hidden w-72 shrink-0 rounded-2xl border border-border/70 bg-card/95 p-4 shadow-sm backdrop-blur lg:flex lg:flex-col'>
          <div className='mb-6 flex items-center gap-3 rounded-xl border border-border/70 bg-muted/30 p-3'>
            {storeLogo ? (
              <Image src={storeLogo} alt='Store logo' width={40} height={40} className='h-10 w-10 rounded-md object-cover' />
            ) : (
              <div className='flex h-10 w-10 items-center justify-center rounded-md bg-primary text-sm font-bold text-primary-foreground'>
                RX
              </div>
            )}
            <div>
              <p className='text-xs uppercase tracking-wide text-muted-foreground'>Store Console</p>
              <p className='text-sm font-semibold'>{storeName}</p>
            </div>
          </div>

          <nav className='flex-1 space-y-1'>
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = pathname.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.disabled ? '#' : item.href}
                  className={cn(
                    'flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
                    item.disabled ? 'pointer-events-none opacity-40' : 'hover:bg-muted/60',
                    active ? 'bg-primary text-primary-foreground hover:bg-primary' : 'text-foreground'
                  )}
                >
                  <Icon className='h-4 w-4' />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>

          <div className='mt-4 rounded-lg border border-border/70 bg-muted/20 p-3 text-xs text-muted-foreground'>
            <p className='font-semibold text-foreground'>{me?.fullName || 'Authenticated user'}</p>
            <p>{me?.email || 'No profile loaded'}</p>
            <p className='mt-1'>Roles: {me?.roles?.join(', ') || 'N/A'}</p>
          </div>
        </aside>

        <div className='flex min-h-[calc(100vh-2rem)] flex-1 flex-col rounded-2xl border border-border/70 bg-card/95 shadow-sm'>
          <header className='sticky top-0 z-20 border-b border-border/70 bg-card/95 px-4 py-3 backdrop-blur lg:px-6'>
            <div className='flex flex-wrap items-center gap-3'>
              <div className='min-w-[220px] flex-1'>
                <AppBreadcrumbs />
                <p className='text-sm font-semibold'>{sectionLabel}</p>
              </div>

              <div className='hidden min-w-[280px] flex-1 items-center gap-2 rounded-lg border border-border/80 bg-muted/40 px-3 py-2 lg:flex'>
                <Search className='h-4 w-4 text-muted-foreground' />
                <Input
                  className='h-7 border-0 bg-transparent px-0 text-sm focus-visible:ring-0'
                  placeholder='Global search: machine, lot, job, operator'
                />
              </div>

              <div className='flex items-center gap-2'>
                <LiveConnectionBadge state={connectionState} lastSyncAt={lastSyncAt} />
                <ThemeToggle />
                <Button variant='ghost' size='sm' aria-label='Notifications'>
                  <Bell className='h-4 w-4' />
                </Button>
                <Button
                  variant='ghost'
                  size='sm'
                  onClick={() => {
                    clearTokens();
                    router.replace('/login');
                  }}
                >
                  <LogOut className='mr-1 h-4 w-4' />
                  Logout
                </Button>
              </div>
            </div>
          </header>

          <div className='border-b border-border/70 px-4 py-2 lg:hidden'>
            <div className='flex gap-2 overflow-x-auto'>
              {navItems
                .filter((item) => !item.disabled)
                .map((item) => {
                  const Icon = item.icon;
                  const active = pathname.startsWith(item.href);
                  return (
                    <Link
                      key={`mobile-${item.href}`}
                      href={item.href}
                      className={cn(
                        'inline-flex items-center gap-1 whitespace-nowrap rounded-md border px-2 py-1 text-xs',
                        active ? 'border-primary bg-primary text-primary-foreground' : 'border-border'
                      )}
                    >
                      <Icon className='h-3.5 w-3.5' />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
            </div>
          </div>

          <main className='flex-1 space-y-6 p-4 lg:p-6'>{children}</main>
        </div>
      </div>
    </div>
  );
}
