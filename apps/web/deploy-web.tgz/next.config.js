/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ['@pillcount/shared', '@pillcount/ui'],
  experimental: {
    typedRoutes: false
  }
};

module.exports = nextConfig;
