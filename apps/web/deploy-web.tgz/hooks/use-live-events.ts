'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { getApiBaseUrl } from '../lib/api';
import { getAccessToken } from '../lib/auth';

export interface LiveEvent {
  type: string;
  payload: Record<string, unknown>;
  emittedAt: string;
}

export function useLiveEvents() {
  const [connectionState, setConnectionState] = useState<'connecting' | 'open' | 'closed' | 'error'>('connecting');
  const [lastSyncAt, setLastSyncAt] = useState<string>('');
  const [events, setEvents] = useState<LiveEvent[]>([]);
  const sourceRef = useRef<EventSource | null>(null);

  useEffect(() => {
    const token = getAccessToken();
    if (!token) {
      setConnectionState('closed');
      return;
    }

    const source = new EventSource(`${getApiBaseUrl()}/live/events?token=${encodeURIComponent(token)}`);
    sourceRef.current = source;

    source.onopen = () => {
      setConnectionState('open');
      setLastSyncAt(new Date().toISOString());
    };

    source.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        const normalized: LiveEvent = {
          type: data.type || 'message',
          payload: data.payload || {},
          emittedAt: data.emittedAt || new Date().toISOString()
        };
        setEvents((prev) => [normalized, ...prev].slice(0, 30));
        setLastSyncAt(new Date().toISOString());
      } catch (_error) {
        // Ignore malformed SSE payloads
      }
    };

    source.onerror = () => {
      setConnectionState('error');
    };

    return () => {
      source.close();
      setConnectionState('closed');
    };
  }, []);

  return useMemo(
    () => ({
      connectionState,
      lastSyncAt,
      events
    }),
    [connectionState, lastSyncAt, events]
  );
}


