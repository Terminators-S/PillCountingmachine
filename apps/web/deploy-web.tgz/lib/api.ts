import { getAccessToken, getRefreshToken, clearTokens, setTokens } from './auth';

const LOCAL_API_BASE_URL = 'http://localhost:4000/api';
const FALLBACK_STATUS_CODES = new Set([404, 502, 503, 504]);
const LOCAL_HOSTNAMES = new Set(['localhost', '127.0.0.1']);
let preferredApiBaseUrl: string | null = null;

function normalizeApiBaseUrl(url: string) {
  return String(url).trim().replace(/\/+$/, '');
}

function buildApiBaseCandidates() {
  const candidates: string[] = [];
  const configuredApiUrl = process.env.NEXT_PUBLIC_API_URL?.trim();
  if (configuredApiUrl) {
    candidates.push(normalizeApiBaseUrl(configuredApiUrl));
  }

  if (typeof window !== 'undefined') {
    candidates.push(normalizeApiBaseUrl(`${window.location.origin}/api`));

    if (LOCAL_HOSTNAMES.has(window.location.hostname)) {
      candidates.push(LOCAL_API_BASE_URL);
    }
  } else {
    candidates.push(LOCAL_API_BASE_URL);
  }

  if (preferredApiBaseUrl) {
    candidates.unshift(preferredApiBaseUrl);
  }

  return Array.from(new Set(candidates.filter(Boolean)));
}

async function fetchFromApi(path: string, init: RequestInit = {}) {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const candidates = buildApiBaseCandidates();
  let lastResponse: Response | null = null;
  let lastNetworkError: unknown = null;

  for (let index = 0; index < candidates.length; index += 1) {
    const baseUrl = candidates[index];
    const hasFallback = index < candidates.length - 1;

    try {
      const response = await fetch(`${baseUrl}${normalizedPath}`, init);
      if (!response.ok && hasFallback && FALLBACK_STATUS_CODES.has(response.status)) {
        lastResponse = response;
        continue;
      }

      preferredApiBaseUrl = baseUrl;
      return response;
    } catch (error) {
      lastNetworkError = error;
      if (!hasFallback) {
        throw error;
      }
    }
  }

  if (lastResponse) {
    return lastResponse;
  }

  if (lastNetworkError instanceof Error) {
    throw lastNetworkError;
  }

  throw new Error('Unable to reach API');
}

export class ApiError extends Error {
  status: number;
  code?: string;
  details?: unknown;

  constructor(message: string, status: number, code?: string, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

async function parseResponse(response: Response) {
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    return response.json();
  }
  return response.text();
}

async function refreshAccessToken() {
  const refreshToken = getRefreshToken();
  if (!refreshToken) return '';

  const response = await fetchFromApi('/auth/refresh', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refreshToken })
  });

  if (!response.ok) {
    clearTokens();
    return '';
  }

  const payload = await response.json();
  if (payload.accessToken && payload.refreshToken) {
    setTokens(payload.accessToken, payload.refreshToken);
    return payload.accessToken;
  }

  return '';
}

export async function apiRequest<T>(path: string, init: RequestInit = {}, retryAuth = true): Promise<T> {
  const accessToken = getAccessToken();
  const headers = new Headers(init.headers || {});
  if (!headers.has('Content-Type') && init.body && !(init.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }
  if (accessToken) {
    headers.set('Authorization', `Bearer ${accessToken}`);
  }

  const response = await fetchFromApi(path, {
    ...init,
    headers
  });

  if (response.status === 401 && retryAuth) {
    const refreshed = await refreshAccessToken();
    if (refreshed) {
      return apiRequest<T>(path, init, false);
    }
  }

  if (!response.ok) {
    const payload = await parseResponse(response);
    if (typeof payload === 'object' && payload !== null) {
      throw new ApiError((payload as any).message || 'Request failed', response.status, (payload as any).code, payload);
    }
    throw new ApiError(String(payload || 'Request failed'), response.status);
  }

  return parseResponse(response) as Promise<T>;
}

export async function downloadFromApi(path: string, filename: string) {
  const token = getAccessToken();
  const response = await fetchFromApi(path, {
    headers: token ? { Authorization: `Bearer ${token}` } : undefined
  });

  if (!response.ok) {
    throw new ApiError('Export failed', response.status);
  }

  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}

export function getApiBaseUrl() {
  return preferredApiBaseUrl || buildApiBaseCandidates()[0] || LOCAL_API_BASE_URL;
}
