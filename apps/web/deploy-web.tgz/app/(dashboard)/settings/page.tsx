'use client';

import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ColumnDef } from '@tanstack/react-table';
import { Button } from '../../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../../components/ui/card';
import { Input } from '../../../components/ui/input';
import { Badge } from '../../../components/ui/badge';
import { DataTable } from '../../../components/data-table';
import { PageHeader } from '../../../components/page-header';
import { apiRequest } from '../../../lib/api';
import { formatDateTime } from '../../../lib/format';
import { ApiKeyCreateResponse, ApiKeyRecord } from '../../../types/api';

const apiKeyColumns: ColumnDef<ApiKeyRecord>[] = [
  { accessorKey: 'name', header: 'Name', cell: ({ row }) => <span className='font-medium'>{row.original.name}</span> },
  { accessorKey: 'keyPrefix', header: 'Key Prefix' },
  {
    accessorKey: 'scopes',
    header: 'Scopes',
    cell: ({ row }) => (
      <div className='flex flex-wrap gap-1'>
        {row.original.scopes.map((scope) => (
          <Badge key={scope}>{scope}</Badge>
        ))}
      </div>
    )
  },
  {
    accessorKey: 'isActive',
    header: 'State',
    cell: ({ row }) => (row.original.isActive ? <Badge variant='success'>Active</Badge> : <Badge variant='danger'>Revoked</Badge>)
  },
  { accessorKey: 'lastUsedAt', header: 'Last Used', cell: ({ row }) => formatDateTime(row.original.lastUsedAt) },
  { accessorKey: 'createdAt', header: 'Created', cell: ({ row }) => formatDateTime(row.original.createdAt) }
];

export default function SettingsPage() {
  const queryClient = useQueryClient();
  const [name, setName] = useState('');
  const [scopes, setScopes] = useState('machine:write,events:write');
  const [plainKey, setPlainKey] = useState('');

  const apiKeys = useQuery({
    queryKey: ['api-keys', 'list'],
    queryFn: () => apiRequest<ApiKeyRecord[]>('/api-keys')
  });

  const createKey = useMutation({
    mutationFn: () =>
      apiRequest<ApiKeyCreateResponse>('/api-keys', {
        method: 'POST',
        body: JSON.stringify({
          name,
          scopes: scopes
            .split(',')
            .map((entry) => entry.trim())
            .filter(Boolean)
        })
      }),
    onSuccess: async (payload) => {
      setPlainKey(payload.plainKey);
      setName('');
      await queryClient.invalidateQueries({ queryKey: ['api-keys', 'list'] });
    }
  });

  const revokeKey = useMutation({
    mutationFn: (id: string) =>
      apiRequest(`/api-keys/${id}`, {
        method: 'DELETE'
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['api-keys', 'list'] });
    }
  });

  return (
    <div className='space-y-6'>
      <PageHeader title='Settings' description='Manage API keys, notification controls, and operational policy defaults.' />

      <Card>
        <CardHeader>
          <CardTitle>Machine API Keys</CardTitle>
        </CardHeader>
        <CardContent className='space-y-3'>
          <div className='grid gap-3 md:grid-cols-3'>
            <div>
              <label className='mb-1 block text-xs font-semibold uppercase text-muted-foreground'>Key Name</label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder='Warehouse Robot Key' />
            </div>
            <div>
              <label className='mb-1 block text-xs font-semibold uppercase text-muted-foreground'>Scopes (comma-separated)</label>
              <Input value={scopes} onChange={(e) => setScopes(e.target.value)} placeholder='machine:write,events:write' />
            </div>
            <div className='flex items-end'>
              <Button onClick={() => createKey.mutate()} disabled={createKey.isPending || !name.trim()} className='w-full'>
                {createKey.isPending ? 'Creating...' : 'Create API Key'}
              </Button>
            </div>
          </div>

          {plainKey ? (
            <div className='rounded-md border border-emerald-300/70 bg-emerald-50 p-3 text-sm text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950/30 dark:text-emerald-300'>
              Save now: <code className='font-mono'>{plainKey}</code>
            </div>
          ) : null}

          {apiKeys.data ? (
            <DataTable
              columns={apiKeyColumns}
              data={apiKeys.data}
              searchPlaceholder='Search API keys...'
              renderRowActions={(row) => (
                <Button size='sm' variant='ghost' disabled={!row.isActive || revokeKey.isPending} onClick={() => revokeKey.mutate(row.id)}>
                  Revoke
                </Button>
              )}
            />
          ) : apiKeys.isLoading ? (
            <p className='text-sm text-muted-foreground'>Loading API keys...</p>
          ) : (
            <p className='text-sm text-red-600'>Failed to load API keys.</p>
          )}
        </CardContent>
      </Card>

      <section className='grid gap-6 md:grid-cols-2'>
        <Card>
          <CardHeader>
            <CardTitle>Webhook Rules</CardTitle>
          </CardHeader>
          <CardContent className='space-y-2 text-sm text-muted-foreground'>
            <p>Configure outbound events in Enterprise phase:</p>
            <ul className='list-disc pl-5'>
              <li><code>job.completed</code> webhook delivery policy</li>
              <li><code>inventory.low_stock</code> alert routing</li>
              <li>Retry + dead-letter behavior</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Tolerance & Notification Profiles</CardTitle>
          </CardHeader>
          <CardContent className='space-y-2 text-sm text-muted-foreground'>
            <p>Profiles can be versioned per store/location:</p>
            <ul className='list-disc pl-5'>
              <li>Default count tolerance percentage</li>
              <li>Expiry warning windows</li>
              <li>Maintenance reminders</li>
            </ul>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
