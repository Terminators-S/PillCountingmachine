'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { loginSchema, registerSchema } from '@pillcount/shared';
import { z } from 'zod';
import { ApiError, apiRequest } from '../../../lib/api';
import { setTokens } from '../../../lib/auth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../../components/ui/card';
import { Input } from '../../../components/ui/input';
import { Button } from '../../../components/ui/button';

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [error, setError] = useState('');

  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' }
  });

  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: { email: '', password: '', fullName: '' }
  });

  async function handleLogin(values: LoginFormValues) {
    setError('');
    try {
      const payload = await apiRequest<{ accessToken: string; refreshToken: string }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(values)
      });
      setTokens(payload.accessToken, payload.refreshToken);
      router.replace('/overview');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Login failed');
    }
  }

  async function handleRegister(values: RegisterFormValues) {
    setError('');
    try {
      const payload = await apiRequest<{ accessToken: string; refreshToken: string }>('/auth/register', {
        method: 'POST',
        body: JSON.stringify(values)
      });
      setTokens(payload.accessToken, payload.refreshToken);
      router.replace('/overview');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Registration failed');
    }
  }

  return (
    <div className='flex min-h-screen items-center justify-center bg-[radial-gradient(circle_at_20%_20%,rgba(37,99,235,0.14),transparent_35%),radial-gradient(circle_at_80%_10%,rgba(34,197,94,0.1),transparent_30%),hsl(var(--background))] p-4'>
      <Card className='w-full max-w-md border-border/80 bg-card/95 shadow-lg'>
        <CardHeader>
          <CardTitle>PillCount Operations Console</CardTitle>
          <CardDescription>Secure sign-in for pharmacy, clinic, and warehouse teams.</CardDescription>
        </CardHeader>

        <CardContent className='space-y-4'>
          <div className='flex items-center gap-2 rounded-lg bg-muted p-1'>
            <Button variant={mode === 'login' ? 'default' : 'ghost'} className='flex-1' onClick={() => setMode('login')}>
              Login
            </Button>
            <Button variant={mode === 'register' ? 'default' : 'ghost'} className='flex-1' onClick={() => setMode('register')}>
              Register
            </Button>
          </div>

          {error ? <p className='rounded-md bg-red-50 p-2 text-sm text-red-700 dark:bg-red-950/40 dark:text-red-300'>{error}</p> : null}

          {mode === 'login' ? (
            <form className='space-y-3' onSubmit={loginForm.handleSubmit(handleLogin)}>
              <div>
                <label className='mb-1 block text-sm font-medium'>Email</label>
                <Input type='email' {...loginForm.register('email')} />
                {loginForm.formState.errors.email ? <p className='mt-1 text-xs text-red-600'>{loginForm.formState.errors.email.message}</p> : null}
              </div>
              <div>
                <label className='mb-1 block text-sm font-medium'>Password</label>
                <Input type='password' {...loginForm.register('password')} />
                {loginForm.formState.errors.password ? <p className='mt-1 text-xs text-red-600'>{loginForm.formState.errors.password.message}</p> : null}
              </div>
              <Button className='w-full' type='submit' disabled={loginForm.formState.isSubmitting}>
                {loginForm.formState.isSubmitting ? 'Signing in...' : 'Sign in'}
              </Button>
            </form>
          ) : (
            <form className='space-y-3' onSubmit={registerForm.handleSubmit(handleRegister)}>
              <div>
                <label className='mb-1 block text-sm font-medium'>Full name</label>
                <Input {...registerForm.register('fullName')} />
                {registerForm.formState.errors.fullName ? <p className='mt-1 text-xs text-red-600'>{registerForm.formState.errors.fullName.message}</p> : null}
              </div>
              <div>
                <label className='mb-1 block text-sm font-medium'>Email</label>
                <Input type='email' {...registerForm.register('email')} />
                {registerForm.formState.errors.email ? <p className='mt-1 text-xs text-red-600'>{registerForm.formState.errors.email.message}</p> : null}
              </div>
              <div>
                <label className='mb-1 block text-sm font-medium'>Password</label>
                <Input type='password' {...registerForm.register('password')} />
                {registerForm.formState.errors.password ? <p className='mt-1 text-xs text-red-600'>{registerForm.formState.errors.password.message}</p> : null}
              </div>
              <Button className='w-full' type='submit' disabled={registerForm.formState.isSubmitting}>
                {registerForm.formState.isSubmitting ? 'Creating account...' : 'Create account'}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
