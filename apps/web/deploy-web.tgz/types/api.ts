export type RoleCode = 'ADMIN' | 'SUPERVISOR' | 'OPERATOR' | 'AUDITOR' | 'VIEWER' | 'API_ONLY';

export type MachineStatus = 'ONLINE' | 'OFFLINE' | 'MAINTENANCE' | 'UNKNOWN';

export type JobStatus = 'CREATED' | 'IN_PROGRESS' | 'COMPLETED' | 'NEEDS_RECOUNT' | 'CANCELLED';

export type InventoryTxnType =
  | 'RECEIVE'
  | 'DISPENSE'
  | 'ADJUST'
  | 'TRANSFER'
  | 'RESERVE'
  | 'RELEASE'
  | 'QUARANTINE'
  | 'WASTE'
  | 'CYCLE_COUNT';

export interface Machine {
  id: string;
  machineCode: string;
  displayName?: string | null;
  location: string;
  firmwareVersion: string;
  status: MachineStatus;
  displayStatus?: MachineStatus;
  lastSeen?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface MachineEventRow {
  id: string;
  machineId: string;
  eventType: string;
  payload?: Record<string, unknown>;
  occurredAt: string;
  receivedAt: string;
  idempotencyKey: string;
  sourceIp?: string | null;
  sourceUserAgent?: string | null;
  machine: Pick<Machine, 'id' | 'machineCode' | 'location' | 'firmwareVersion'>;
}

export interface EventListResponse {
  page: number;
  pageSize: number;
  total: number;
  rows: MachineEventRow[];
}

export interface PillType {
  id: string;
  code: string;
  name: string;
  dosageMg?: number | null;
  manufacturer?: string | null;
  barcode?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Lot {
  id: string;
  pillTypeId: string;
  lotNumber: string;
  expiryDate: string;
  receivedDate: string;
  unitCost: string;
  location: string;
  isQuarantined: boolean;
  createdAt: string;
  updatedAt: string;
  pillType?: Pick<PillType, 'id' | 'code' | 'name'>;
}

export interface InventoryBalance {
  id: string;
  pillTypeId: string;
  lotId: string;
  location: string;
  onHand: number;
  reserved: number;
  quarantined: number;
  updatedAt: string;
  pillType: Pick<PillType, 'id' | 'code' | 'name'>;
  lot: Lot;
}

export interface InventoryMovement {
  id: string;
  txnType: InventoryTxnType;
  quantity: number;
  location: string;
  fromLocation?: string | null;
  toLocation?: string | null;
  createdAt: string;
  idempotencyKey?: string | null;
  pillType: Pick<PillType, 'id' | 'code' | 'name'>;
  lot?: Pick<Lot, 'id' | 'lotNumber' | 'expiryDate'> | null;
  machine?: Pick<Machine, 'id' | 'machineCode'> | null;
  operator?: { id: string; email: string; fullName: string } | null;
}

export interface CountingJob {
  id: string;
  jobNumber: string;
  machineId: string;
  pillTypeId: string;
  targetQty: number;
  actualQty?: number | null;
  lotPreferenceId?: string | null;
  tolerancePct: string;
  status: JobStatus;
  createdById: string;
  operatorId?: string | null;
  startedAt?: string | null;
  completedAt?: string | null;
  notes?: string | null;
  createdAt: string;
  updatedAt: string;
  machine: Machine;
  pillType: PillType;
  lotPreference?: Lot | null;
  operator?: { id: string; email: string; fullName: string } | null;
  createdBy?: { id: string; email: string; fullName: string };
}

export interface ReportsOverview {
  machinesTotal: number;
  machinesOnline: number;
  jobsTotal: number;
  jobsCompleted: number;
  pillsTotal: number;
  inventoryMovements: number;
}

export interface ThroughputRow {
  jobId: string;
  jobNumber: string;
  machineCode: string;
  pillTypeCode: string;
  pillName: string;
  targetQty: number;
  actualQty: number;
  completedAt: string;
}

export interface ValuationRow {
  location: string;
  totalValue: number;
  lines: number;
}

export interface ApiKeyRecord {
  id: string;
  name: string;
  keyPrefix: string;
  scopes: string[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  lastUsedAt?: string | null;
}

export interface ApiKeyCreateResponse {
  id: string;
  name: string;
  keyPrefix: string;
  scopes: string[];
  plainKey: string;
  createdAt: string;
}

export interface UserRow {
  id: string;
  email: string;
  fullName: string;
  isActive: boolean;
  createdAt: string;
  roles: RoleCode[];
}

export interface RoleRow {
  id: string;
  code: RoleCode;
  name: string;
  permissions?: string[];
}

export interface AuditLogRow {
  id: string;
  actorType: 'USER' | 'API_KEY' | 'SYSTEM';
  actorUserId?: string | null;
  actorApiKeyId?: string | null;
  action: string;
  resourceType: string;
  resourceId?: string | null;
  requestId?: string | null;
  ipAddress?: string | null;
  userAgent?: string | null;
  metadata?: Record<string, unknown> | null;
  createdAt: string;
  actorUser?: { id: string; email: string; fullName: string } | null;
  actorApiKey?: { id: string; name: string; keyPrefix: string } | null;
}

export interface MeProfile {
  id: string;
  email: string;
  fullName: string;
  roles: RoleCode[];
}
